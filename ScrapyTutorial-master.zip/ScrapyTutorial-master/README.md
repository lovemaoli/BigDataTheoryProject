# ScrapyTutorial
Scrapy Tutorial

《Python3网络爬虫开发实战（第一版）》见 v1 分支。

《Python3网络爬虫开发实战（第二版）》见 master 分支。